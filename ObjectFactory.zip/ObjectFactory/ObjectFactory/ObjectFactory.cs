﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectFactory
{
    class ObjectFactory : IObjectFactory
    {
        public ObjectFactory()
        {
            ImplementationTypeMapping = new List<TypeMapping>();
        }

        public List<TypeMapping> ImplementationTypeMapping { get; set; }


        public object Create(string name, params object[] arguments)
        {
            var possibleImplementations = ImplementationTypeMapping.Where(x => x.T1.Name.ToLowerInvariant().Equals(name.ToLowerInvariant())
                                                                            || x.T1.Name.ToLowerInvariant().Replace("´", "").Replace("`", "").Replace("0", "").Replace("1", "").Equals(name.ToLowerInvariant())
                                                                            || x.T1.FullName.ToLowerInvariant().Equals(name));

            foreach (var possibleImplementation in possibleImplementations)
            {
                var instance = CreateInstance(possibleImplementation, arguments);
                if (!instance.Equals(default))
                    return instance;
            }

            throw new Exception($"Could not create {name}");
        }

        public object Create(Type interfaceType, Type[] genericTypes, params object[] arguments)
        {
            var possibleImplementations = ImplementationTypeMapping.Where(x => x.T1.Equals(interfaceType));

            foreach (var possibleImplementation in possibleImplementations)
            {
                var instance = CreateInstance(possibleImplementation, arguments);
                if (!instance.Equals(default))
                    return instance;
            }

            possibleImplementations = ImplementationTypeMapping.Where(x => x.T1.Equals(interfaceType.GetGenericTypeDefinition()));

            foreach (var possibleImplementation in possibleImplementations)
            {
                var possibleGenericType = possibleImplementation.T2.MakeGenericType(genericTypes);
                var instance = Activator.CreateInstance(possibleGenericType, arguments);
                if (!instance.Equals(default))
                    return instance;
            }

            throw new Exception($"Could not create {interfaceType.Name}");
        }

        public object Create(string name, Type[] genericTypes, params object[] arguments)
        {
            var possibleImplementations = ImplementationTypeMapping.Where(x => x.T1.Name.ToLowerInvariant().Equals(name.ToLowerInvariant()) 
                                                                            || x.T1.Name.ToLowerInvariant().Replace("´", "").Replace("`", "").Replace("0", "").Replace("1", "").Equals(name.ToLowerInvariant())
                                                                            || x.T1.FullName.ToLowerInvariant().Equals(name)).Select(x => new TypeMapping(x.T1.GetGenericTypeDefinition(), x.T2));

            foreach (var possibleImplementation in possibleImplementations)
            {
                var possibleGenericType = possibleImplementation.T2.MakeGenericType(genericTypes);
                var instance = Activator.CreateInstance(possibleGenericType, arguments);
                if (!instance.Equals(default))
                    return instance;
            }

            throw new Exception($"Could not create {name}");
        }

        public TInterface Create<TInterface>(params object[] arguments)
        {
            var interfaceType = typeof(TInterface);
            var possibleImplementations = ImplementationTypeMapping.Where(x => x.T1.Equals(interfaceType));

            foreach(var possibleImplementation in possibleImplementations)
            {
                var instance = CreateInstance<TInterface>(possibleImplementation, arguments);
                if(!instance.Equals(default))
                    return instance;
            }

            possibleImplementations = ImplementationTypeMapping.Where(x => x.T1.Equals(interfaceType.GetGenericTypeDefinition()));

            foreach (var possibleImplementation in possibleImplementations)
            {
                var possibleGenericType = possibleImplementation.T2.MakeGenericType(interfaceType.GetGenericArguments());
                var instance = (TInterface) Activator.CreateInstance(possibleGenericType, arguments);
                if (!instance.Equals(default))
                    return instance;
            }

            throw new Exception($"Could not create {interfaceType.Name}");
        }

        public object Create(Type interfaceType, params object[] arguments)
        {
            var possibleImplementations = ImplementationTypeMapping.Where(x => x.T1.Equals(interfaceType));

            foreach (var possibleImplementation in possibleImplementations)
            {
                var instance = CreateInstance(possibleImplementation, arguments);
                if (!instance.Equals(default))
                    return instance;
            }

            possibleImplementations = ImplementationTypeMapping.Where(x => x.T1.Equals(interfaceType.GetGenericTypeDefinition()));

            foreach (var possibleImplementation in possibleImplementations)
            {
                var possibleGenericType = possibleImplementation.T2.MakeGenericType(interfaceType.GetGenericArguments());
                var instance = Activator.CreateInstance(possibleGenericType, arguments);
                if (!instance.Equals(default))
                    return instance;
            }

            throw new Exception($"Could not create {interfaceType.Name}");
        }

        private object CreateInstance(TypeMapping possibleImplementation, object[] arguments)
        {
            return Activator.CreateInstance(possibleImplementation.T2, arguments);
        }

        private TInterface CreateInstance<TInterface>(TypeMapping possibleImplementation, object[] arguments)
        {
            return (TInterface) Activator.CreateInstance(possibleImplementation.T2, arguments);
        }

        public void Register<TInterface, TImplementation>()
        {
            if (typeof(TImplementation).IsInterface)
                throw new Exception("Can not have interface as implementation");
            if (typeof(TImplementation).IsAbstract)
                throw new Exception("Can not have abstract class as implementation");
            ImplementationTypeMapping.Add(new TypeMapping(typeof(TInterface), typeof(TImplementation)));
        }

        public void Register(Type interfaceType, Type implementationType)
        {
            if (implementationType.IsInterface)
                throw new Exception("Can not have interface as implementation");
            if (implementationType.IsAbstract)
                throw new Exception("Can not have abstract class as implementation");
            ImplementationTypeMapping.Add(new TypeMapping(interfaceType, implementationType));
        }
    }
}
