﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectFactory
{
    interface IObjectFactory 
    {
        public object Create(string name, params object[] arguments);

        public object Create(Type interfaceType, Type[] genericTypes, params object[] arguments);

        public object Create(string name, Type[] genericTypes, params object[] arguments);

        public TInterface Create<TInterface>(params object[] arguments);

        public object Create(Type interfaceType, params object[] arguments);

        public void Register<TInterface, TImplementation>();

        public void Register(Type interfaceType, Type implementationType);
    }
}
