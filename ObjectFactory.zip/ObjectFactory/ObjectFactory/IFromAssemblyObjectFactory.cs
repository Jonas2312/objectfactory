﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectFactory
{
    interface IFromAssemblyObjectFactory
    {
        object JustCreateIt(string interfaceName, string[] genericTypeNames = null, object[] arguments = null);
    }
}
