﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectFactory
{
    class TypeMapping : ITypeMapping
    {
        public TypeMapping(Type t1, Type t2)
        {
            T1 = t1;
            T2 = t2;
        }

        public Type T1 { get; set; }
        public Type T2 { get; set; }
    }
}
