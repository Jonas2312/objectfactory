﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ObjectFactory
{
    class FromAssemblyObjectFactory : IFromAssemblyObjectFactory
    {
        public object JustCreateIt(string interfaceName, string[] genericTypeNames = null, object[] arguments = null)
        {
            var availableTypes = AppDomain.CurrentDomain.GetAssemblies().SelectMany(t => t.GetTypes()).ToList();
            var interfaceType = availableTypes.FirstOrDefault(x => x.Name.ToLowerInvariant().Equals(interfaceName.ToLowerInvariant())
                                                                            || x.Name.ToLowerInvariant().Replace("´", "").Replace("`", "").Replace("0", "").Replace("1", "").Equals(interfaceName.ToLowerInvariant())
                                                                            || x.FullName.ToLowerInvariant().Equals(interfaceName));
            if (interfaceType == null)
                throw new Exception($"Could not find interface with name {interfaceName}");

            
            if(genericTypeNames != null && genericTypeNames.Length > 0)
            {
                List<Type> genericTypes = genericTypeNames.Select(y => availableTypes.FirstOrDefault(x => x.Name.ToLowerInvariant().Equals(y.ToLowerInvariant())
                                                                            || x.Name.ToLowerInvariant().Replace("´", "").Replace("`", "").Replace("0", "").Replace("1", "").Replace("2", "").Replace("3", "").Replace("4", "").Equals(y.ToLowerInvariant())
                                                                            || x.FullName.ToLowerInvariant().Equals(y))).ToList();
                genericTypes.Remove(null);
                if (genericTypes.Count == 0)
                    genericTypes.AddRange(GetPrimitiveTypes(genericTypeNames));
                
                var possibleImplementations = availableTypes.Where(x => x.IsAssignableTo(interfaceType)).ToList();
                foreach (var possibleImplementation in possibleImplementations)
                {
                    try
                    {
                        var possibleGenericType = possibleImplementation.MakeGenericType(genericTypes.ToArray());
                        var instance = Activator.CreateInstance(possibleGenericType, arguments);
                        if (!instance.Equals(default))
                            return instance;
                    }
                    catch(Exception e)
                    {
                        //Console.WriteLine(possibleImplementation.Name + " - "+ e.Message + " - " + e.StackTrace);
                    } 
                }
            }

            else
            {
                var possibleImplementations = availableTypes.Where(x => x.IsAssignableTo(interfaceType)).ToList();
                foreach (var possibleImplementation in possibleImplementations)
                {
                    try
                    {
                        var instance = Activator.CreateInstance(possibleImplementation, arguments);
                        if (!instance.Equals(default))
                            return instance;
                    }
                    catch
                    {

                    }
                }
            }


            throw new Exception($"Could not find any implementations for interface with name {interfaceName}");
        }

        private List<Type> GetPrimitiveTypes(string[] genericTypeNames)
        {
            List<Type> resultList = new List<Type>();

            foreach(var v in genericTypeNames)
            {
                resultList.Add(GetPrimitiveType(v));
            }

            return resultList;
        }

        private Type GetPrimitiveType(string v)
        {
            if (v.ToLowerInvariant().Contains("int"))
                return typeof(int);
            if (v.ToLowerInvariant().Contains("string"))
                return typeof(string);
            if (v.ToLowerInvariant().Contains("float"))
                return typeof(float);
            if (v.ToLowerInvariant().Contains("double"))
                return typeof(double);
            if (v.ToLowerInvariant().Contains("decimal"))
                return typeof(decimal);
            if (v.ToLowerInvariant().Contains("bool"))
                return typeof(bool);
            throw new NotImplementedException();

        }
    }
}
