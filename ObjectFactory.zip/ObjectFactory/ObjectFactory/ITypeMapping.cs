﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectFactory
{
    interface ITypeMapping
    {
        Type T1 { get; set; }
        Type T2 { get; set; }
    }
}
