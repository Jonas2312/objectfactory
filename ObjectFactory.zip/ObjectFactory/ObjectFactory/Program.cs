﻿using ObjectFactory.TypeAbc;
using System;
using System.Collections;
using System.Collections.Generic;

namespace ObjectFactory
{
    class Program
    {
        static void Main(string[] args)
        {
            var test = typeof(Dictionary<,>);
            var test2 = test.MakeGenericType(new[] { typeof(int), typeof(int) });

            var objectFactory = new ObjectFactory();

            objectFactory.Register(typeof(IList<>), typeof(List<>));

            var v = (List<int>) objectFactory.Create("IList", new Type[] { typeof(int) });

            var objectFactory2 = new FromAssemblyObjectFactory();

            var v2 = objectFactory2.JustCreateIt("idictionary", new[] { "int", "int" });

            var dict = (IDictionary<int, int>)v2;

            Console.WriteLine(v2.GetType().FullName);
        }
    }
}
